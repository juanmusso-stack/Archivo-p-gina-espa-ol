const words = ["El", "gato", "está", "en", "la", "mesa"];
const correctOrder = ["El", "gato", "está", "en", "la", "mesa"];
const wordsContainer = document.getElementById("words-container");
const result = document.getElementById("result");
const checkButton = document.getElementById("check-button");

// Función para mezclar las palabras
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Función para crear los elementos de palabras
function createWords() {
    const shuffledWords = shuffle([...words]);
    shuffledWords.forEach(word => {
        const wordElement = document.createElement("span");
        wordElement.textContent = word;
        wordElement.classList.add("word");
        wordElement.draggable = true;

        // Eventos para arrastrar y soltar
        wordElement.addEventListener("dragstart", (e) => {
            e.dataTransfer.setData("text/plain", word);
            setTimeout(() => {
                wordElement.style.display = "none";
            }, 0);
        });

        wordElement.addEventListener("dragend", () => {
            wordElement.style.display = "inline-block";
        });

        wordsContainer.appendChild(wordElement);
    });

    // Eventos para el contenedor de palabras
    wordsContainer.addEventListener("dragover", (e) => {
        e.preventDefault();
    });

    wordsContainer.addEventListener("drop", (e) => {
        e.preventDefault();
        const draggedWord = e.dataTransfer.getData("text/plain");
        const targetWord = e.target.textContent;

        // Intercambiar las palabras
        const draggedElement = Array.from(wordsContainer.children).find(word => word.textContent === draggedWord);
        const targetElement = Array.from(wordsContainer.children).find(word => word.textContent === targetWord);

        if (draggedElement && targetElement) {
            const draggedIndex = Array.from(wordsContainer.children).indexOf(draggedElement);
            const targetIndex = Array.from(wordsContainer.children).indexOf(targetElement);

            if (draggedIndex !== targetIndex) {
                wordsContainer.insertBefore(draggedElement, targetIndex > draggedIndex ? targetElement.nextSibling : targetElement);
            }
        }
    });
}

// Función para comprobar el orden
function checkOrder() {
    const selectedWords = Array.from(wordsContainer.children).map(word => word.textContent);
    if (JSON.stringify(selectedWords) === JSON.stringify(correctOrder)) {
        result.textContent = "¡Correcto! Has ordenado la frase correctamente.";
    } else {
        result.textContent = "Incorrecto. Intenta de nuevo.";
    }
}

// Inicializar el juego
createWords();
checkButton.addEventListener("click", checkOrder);